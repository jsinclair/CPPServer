/* -*- mode: c -*- */

/*
 * Copyright (c) 2005-2009 Jaroslav Gresula
 *
 * Distributed under the MIT license (See accompanying file
 * LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
 *
 */
#ifndef CONFIG_JG2316_H__
#define CONFIG_JG2316_H__

#define JAG_SIZEOF_VOID_P 8

#endif
/** EOF @file */
